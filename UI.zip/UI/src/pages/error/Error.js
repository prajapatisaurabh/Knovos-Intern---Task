import React from "react";
import { Button, Container, Navbar, Nav, Row, Col } from "react-bootstrap";
import { Link } from "react-router-dom";

const Error = () => {
  return (
    <>
      <Navbar bg="light" variant="light">
        <Container>
          <Navbar.Brand to="/dashboard">Thita Admin</Navbar.Brand>
          <Nav className="me-auto">
            <Nav.Link>
              <Link to="/dashboard">Home</Link>
            </Nav.Link>
            <Nav.Link>
              <Link to="/code">Code</Link>
            </Nav.Link>
          </Nav>
        </Container>
      </Navbar>
      <Container>
        <h1>Error Page </h1>
      </Container>
    </>
  );
};

export default Error;
