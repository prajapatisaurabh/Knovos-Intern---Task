import React, { useState } from "react";
import { Button, Container, Navbar, Nav, Row, Col } from "react-bootstrap";
import { useDispatch } from "react-redux";
import { Link } from "react-router-dom";
import styled from "styled-components";
import { fetchUserData } from "../../api/authenticationService";

const MainWrapper = styled.div`
  padding-top: 40px;
`;

export const Dashboard = (props) => {
  const dispatch = useDispatch();
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState({});

  React.useEffect(() => {
    fetchUserData()
      .then((response) => {
        setData(response.data);
      })
      .catch((e) => {
        localStorage.clear();
        props.history.push("/");
      });
  }, []);

  const logOut = () => {
    localStorage.clear();
    props.history.push("/");
  };

  return (
    <>
      <Navbar bg="light" variant="light">
        <Container>
          <Navbar.Brand to="/dashboard">Thita Admin</Navbar.Brand>
          <Nav className="me-auto">
            <Nav.Link>
              <Link to="/dashboard">Home</Link>
            </Nav.Link>
            <Nav.Link>
              <Link to="/code">Code</Link>
            </Nav.Link>
            <Nav.Link onClick={() => logOut()}>Logout</Nav.Link>
          </Nav>
        </Container>
      </Navbar>
      <Container>
        <Row>
          <Col>
            <h4>Hello {data && `${data.firstName} ${data.lastName}`}</h4>
          </Col>
          <Col>
            {data &&
              data.roles &&
              data.roles.filter((value) => value.roleCode === "ADMIN").length >
                0 && <Button type="variant">Add User</Button>}
          </Col>
        </Row>
      </Container>
    </>
  );
};
