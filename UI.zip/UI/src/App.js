import logo from "./logo.svg";
import "./App.css";
import { BrowserRouter, Switch, Route, Link } from "react-router-dom";
import LoginPage from "./pages/login/LoginPage";
import { Dashboard } from "./pages/dashboard/dashboard";
import CodePage from "./pages/code/CodePage";
import Error from "./pages/error/Error";

function App() {
  return (
    <BrowserRouter>
      <Switch>
        <Route exact path="/" component={LoginPage} />
        <Route exact path="/dashboard" component={Dashboard} />
        <Route exact path="/code" component={CodePage} />
        <Route path="*" component={Error} />
      </Switch>
    </BrowserRouter>
  );
}

export default App;
