package com.thita.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThitaInfoAppApplication {		


	public static void main(String[] args) {
		SpringApplication.run(ThitaInfoAppApplication.class, args);
	}



    /*
    * Below code for first time run when there is no user in database;
    * */
//    @Autowired
//    private PasswordEncoder passwordEncoder;
//
//    @Autowired
//    private UserDetailsRepository userDetailsRepository;
//	@PostConstruct
//	protected void init() {
//
//		List<Authority> authorityList=new ArrayList<>();
//
//		authorityList.add(createAuthority("ADMIN","Admin role"));
//		//authorityList.add(createAuthority("ADMIN","Admin role"));
//
//		User user=new User();
//
//		user.setUserName("admin");
//		user.setFirstName("admin");
//		user.setLastName("S");
//
//		user.setPassword(passwordEncoder.encode("admin"));
//		user.setEnabled(true);
//		user.setAuthorities(authorityList);
//
//		userDetailsRepository.save(user);
//	}
//
//
//	private Authority createAuthority(String roleCode,String roleDescription) {
//		Authority authority=new Authority();
//		authority.setRoleCode(roleCode);
//		authority.setRoleDescription(roleDescription);
//		return authority;
//	}
	
		

}
